# Security Policy

## Reporting a Vulnerability

If you discover any security related issues, please email messhias@gmail.com or
eric.schricker@adiutabyte.de instead of using the issue tracker.
